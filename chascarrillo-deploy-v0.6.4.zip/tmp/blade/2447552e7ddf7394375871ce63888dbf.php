<!-- Start top horizontal -->
<?php if(!empty($me->top_menu)): ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">AppName</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <?php $__currentLoopData = $me->top_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_array($subMenu) && count($subMenu) > 0): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown<?php echo e($key); ?>" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo e($me->_($key)); ?>

                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown<?php echo e($key); ?>">
                                <?php $__currentLoopData = $subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subKey => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item" href="<?php echo e($url); ?>"><?php echo e($me->_($subKey)); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e($subMenu); ?>"><?php echo e($me->_($key)); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </nav>
<?php endif; ?><?php /**PATH /var/www/html/Templates/common/partial/top_bar.blade.php ENDPATH**/ ?>