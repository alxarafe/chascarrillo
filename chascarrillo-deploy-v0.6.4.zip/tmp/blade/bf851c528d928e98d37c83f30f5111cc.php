<!-- Start sidebar menu -->
<?php if(!empty($me->sidebar_menu)): ?>
    <div class="sidebar">
        <?php $__currentLoopData = $me->sidebar_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h6 class="px-3 mt-3"><?php echo e(ucfirst($key)); ?></h6>
            <?php $__currentLoopData = $subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subKey => $subSubMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_array($subSubMenu)): ?>
                    <div class="px-3">
                        <h6><?php echo e(ucfirst($subKey)); ?></h6>
                        <?php $__currentLoopData = $subSubMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuKey => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($url); ?>"><?php echo e(ucfirst(last(explode('|', $menuKey)))); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e($subSubMenu); ?>"><?php echo e(ucfirst($subKey)); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH /var/www/html/Templates/common/partial/side_bar.blade.php ENDPATH**/ ?>