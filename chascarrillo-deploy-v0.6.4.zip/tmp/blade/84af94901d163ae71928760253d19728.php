<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('component.card', ['title' => 'Public page', 'name' => 'public']); ?>
        <p>The requested page has not been found!</p>
        <p>Go to the <a href="index.php?module=Admin&controller=Auth">user login page</a> to access the application.</p>
        <p>You can access the settings at the following <a href="index.php?module=Admin&controller=Config">link</a>.</p>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('partial.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/src/Modules/Admin/Templates/page/error404.blade.php ENDPATH**/ ?>