<?php $__env->startComponent('layout.div'); ?>
    <?php echo $__env->make('partial.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/Templates/common/partial/body_empty.blade.php ENDPATH**/ ?>