<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class SkeletonExampleTest extends TestCase
{
    /**
     * A basic test example.
     */
    public function testThatTrueIsTrue(): void
    {
        /** @phpstan-ignore-next-line */
        $this->assertTrue(true);
    }
}
