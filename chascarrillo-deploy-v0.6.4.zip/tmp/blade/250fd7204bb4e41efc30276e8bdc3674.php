<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('form.form', []); ?>
        <?php $__env->startComponent('layout.div', ['fluid' => true]); ?>
            <?php $__env->slot('slot'); ?>
                <?php $__env->startComponent('layout.row',[]); ?>
                    <?php $__env->slot('slot'); ?>
                        <?php $__env->startComponent('layout.column',[]); ?>
                            <?php $__env->slot('slot'); ?>
                                <?php $__env->startComponent('component.card', ['title' => $me->_('miscellaneous')]); ?>
                                    <?php $__env->slot('slot'); ?>
                                        <?php echo $__env->make('form.select', ['name' => 'theme', 'label' => $me::_('theme'), 'values' => $me->themes, 'value' => $me->data->main->theme ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('form.select', ['name' => 'language', 'label' => $me::_('language'), 'values' => $me->languages, 'value' => $me->data->main->language ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('form.checkbox', ['name' => 'debug', 'label' => $me::_('use_debugbar'), 'value' => $me->data->security->debug ?? false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php $__env->endSlot(); ?>
                                <?php echo $__env->renderComponent(); ?>
                                <?php $__env->startComponent('component.card', ['title' => $me->_('connection')]); ?>
                                    <?php $__env->slot('slot'); ?>
                                        <?php
                                            $readonly = $me->pdo_connection ? ['readonly' => null] : [];
                                        ?>
                                        <?php echo $__env->make('form.select', ['name' => 'type', 'label' => $me->_('db_type'), 'values' => $me->dbtypes, 'value' => $me->data->db->type, 'attributes' => $readonly], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('form.input', ['type' => 'text', 'name' => 'host', 'label' => $me->_('db_host'), 'value' => $me->data->db->host ?? 'localhost', 'attributes' => $readonly], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('form.input', ['type' => 'text', 'name' => 'user', 'label' => $me->_('db_user'), 'value' => $me->data->db->user ?? '', 'attributes' => $readonly], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('form.input', ['type' => 'password', 'name' => 'pass', 'label' => $me->_('db_password'), 'value' => $me->data->db->pass ?? '', 'attributes' => $readonly], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php $__env->endSlot(); ?>
                                <?php echo $__env->renderComponent(); ?>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                        <?php $__env->startComponent('layout.column',[]); ?>
                            <?php $__env->startComponent('component.card', ['title' => $me->_('database_preferences')]); ?>
                                <?php $__env->slot('slot'); ?>
                                    <?php echo $__env->make('form.input', ['type' => 'text', 'name' => 'prefix', 'label' => 'DB Prefix', 'value' => $me->data->db->prefix ?? 'alx_'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('form.input', ['type' => 'text', 'name' => 'charset', 'label' => 'charset', 'value' => $me->data->db->charset ?? 'utf8mb4'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('form.input', ['type' => 'text', 'name' => 'collation', 'label' => 'collation', 'value' => $me->data->db->collation ?? 'utf8mb4_unicode_ci'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php $__env->endSlot(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('component.card', ['title' => $me->_('database')]); ?>
                                <?php $__env->slot('slot'); ?>
                                    <?php echo $__env->make('form.input', ['type' => 'text', 'name' => 'name', 'label' => $me->_('db_name'), 'value' => $me->data->db->name ?? 'alxarafe'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('form.input', ['type' => 'number', 'name' => 'port', 'label' => $me->_('db_port'), 'value' => $me->data->db->port ?? 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php $__env->endSlot(); ?>
                            <?php echo $__env->renderComponent(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('component.button', ['type'=>'submit', 'name'=>'action', 'value'=>'save']); ?>
                    <?php echo $me->_('save_configuration'); ?>

                <?php echo $__env->renderComponent(); ?>
                <?php if($me->pdo_connection ?? false): ?>
                    <?php if(!$me->pdo_db_exists ?? false): ?>
                        <?php $__env->startComponent('component.button', ['type'=>'submit', 'name'=>'action', 'value'=>'createDatabase']); ?>
                            <?php echo $me->_('create_database'); ?>

                        <?php echo $__env->renderComponent(); ?>
                    <?php else: ?>
                        <?php $__env->startComponent('component.button', ['type'=>'submit', 'name'=>'action', 'value'=>'runMigrations']); ?>
                            <?php echo $me->_('go_migrations'); ?>

                        <?php echo $__env->renderComponent(); ?>
                    <?php endif; ?>
                    <?php $__env->startComponent('component.button', ['type'=>'submit', 'name'=>'action', 'value'=>'regenerate', 'class'=>'warning']); ?>
                        <?php echo $me->_('regenerate'); ?>

                    <?php echo $__env->renderComponent(); ?>
                    <?php $__env->startComponent('component.button', ['type'=>'submit', 'name'=>'action', 'value'=>'exit', 'class' => 'danger']); ?>
                        <?php echo $me->_('exit'); ?>

                    <?php echo $__env->renderComponent(); ?>
                <?php endif; ?>
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Prueba de script -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('partial.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/src/Modules/Admin/Templates/page/config.blade.php ENDPATH**/ ?>