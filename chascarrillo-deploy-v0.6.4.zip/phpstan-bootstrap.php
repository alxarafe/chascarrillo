<?php

define('BASE_PATH', __DIR__ . '/public');
define('BASE_URL', 'http://localhost');
define('APP_PATH', __DIR__);
define('ALX_PATH', __DIR__ . '/vendor/alxarafe/alxarafe');
