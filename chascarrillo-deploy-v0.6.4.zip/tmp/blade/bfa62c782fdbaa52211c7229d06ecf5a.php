<!DOCTYPE html>
<html lang="<?php echo $me->config->main->language ?? 'en'; ?>">
<head>
    <title><?php echo $me->title; ?></title>
    <?php echo $__env->make('partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="container">
<h1><?php echo e($me->title ?? 'Alxarafe'); ?></h1>
<?php
    $_body = 'body_' . ($empty ?? false ? 'empty' : 'standard');
?>
<?php echo $__env->make('partial.' . $_body, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /var/www/html/Templates/common/partial/layout/main.blade.php ENDPATH**/ ?>