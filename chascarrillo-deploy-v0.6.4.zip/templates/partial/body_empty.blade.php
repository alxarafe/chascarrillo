<div class="empty-body-container">
    @yield('content')
</div>

<style>
    .empty-body-container {
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        background-color: #f8f9fa;
    }
</style>
