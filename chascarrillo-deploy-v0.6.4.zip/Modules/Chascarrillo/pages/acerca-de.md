---
title: Acerca de
slug: acerca-de
type: page
in_menu: true
menu_order: 1
is_published: true
---

# Acerca de Chascarrillo

Este es un ejemplo de página estática gestionada a través de archivos Markdown.
Puedes editar este archivo en `Content/pages/acerca-de.md`.
