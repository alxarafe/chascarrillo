<!-- Templates/common/form/select.blade.php -->
<div class="form-group">
    <label for="<?php echo $name; ?>" class="form-label"><?php echo $label; ?></label>
    <select class="form-select" name="<?php echo $name; ?>" class="form-control" id="<?php echo $name; ?>">
        <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo $option; ?>" <?php if($value === $option): ?> selected <?php endif; ?>><?php echo $text; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH /var/www/html/Templates/common/form/select.blade.php ENDPATH**/ ?>