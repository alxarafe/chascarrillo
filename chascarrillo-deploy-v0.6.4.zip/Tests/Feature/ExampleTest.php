<?php

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

class SkeletonFeatureExampleTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function testThatTrueIsTrue(): void
    {
        /** @phpstan-ignore-next-line */
        $this->assertTrue(true);
    }
}
