<div id="id_container" class="id_container">
    <?php echo $__env->make('partial.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partial.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="id-right">
        <?php echo $__env->make('partial.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<?php /**PATH /var/www/html/Templates/common/partial/body_standard.blade.php ENDPATH**/ ?>