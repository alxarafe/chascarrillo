<!-- Templates/common/form/input.blade.php -->
<?php
    use Alxarafe\Lib\Functions;
    $_attributes = Functions::htmlAttributes($attributes ?? []);
?>
<div class="form-group">
    <label for="<?php echo $name; ?>" class="form-label"><?php echo $label; ?></label>
    <input type="<?php echo $type; ?>" name="<?php echo $name; ?>" class="form-control" id="<?php echo $name; ?>"
           placeholder="<?php echo $label; ?>" value="<?php echo $value ?? ''; ?>" <?php echo $_attributes; ?>>
</div>
<?php /**PATH /var/www/html/Templates/common/form/input.blade.php ENDPATH**/ ?>