<?php

const BASE_PATH = '';
const BASE_URL = '';
const APP_PATH = '';
const ALX_PATH = '';
