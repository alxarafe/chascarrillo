<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('layout.div', ['fluid' => true]); ?>
        <?php $__env->slot('slot'); ?>
            <?php $__env->startComponent('layout.row',[]); ?>
                <button id="startProcess" class="btn btn-primary center">Iniciar Proceso</button>
                <ul id="results" class="list-group mt-3"></ul>
            <?php echo $__env->renderComponent(); ?>
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        document.getElementById('startProcess').addEventListener('click', function () {
            const resultsContainer = document.getElementById('results');
            resultsContainer.innerHTML = '';

            fetch('<?php echo $me->url(); ?>&action=getProcesses')
                .then(response => response.json())
                .then(actions => {
                    // Paso 2: Ejecutar acciones secuencialmente
                    const executeNext = (index) => {
                        if (index >= actions.length) {
                            return;
                        }

                        const action = actions[index];
                        const listItem = document.createElement('li');
                        listItem.className = 'list-group-item';
                        listItem.textContent = 'Executing: ' + action.name;
                        resultsContainer.appendChild(listItem);

                        fetch('<?php echo $me->url(); ?>&action=ExecuteProcess', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                            body: new URLSearchParams(action)
                        })
                            .then(response => response.json())
                            .then(data => {
                                listItem.textContent = data.message;
                                executeNext(index + 1);
                            })
                            .catch(() => {
                                listItem.textContent = 'Error executing ' + action.name;
                            });
                    };

                    executeNext(0); // Inicia el proceso
                })
                .catch(() => {
                    const errorItem = document.createElement('li');
                    errorItem.className = 'list-group-item list-group-item-danger';
                    errorItem.textContent = 'Error getting the actions';
                    resultsContainer.appendChild(errorItem);
                });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('partial.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/src/Modules/Admin/Templates/page/migration.blade.php ENDPATH**/ ?>